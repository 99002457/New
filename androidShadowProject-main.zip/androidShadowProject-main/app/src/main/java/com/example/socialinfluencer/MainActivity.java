package com.example.socialinfluencer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Fragment;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import static com.example.socialinfluencer.Login.fAuth;
import static com.example.socialinfluencer.Login.mGoogleSignInClient;
public class MainActivity extends AppCompatActivity {

    Button First,Second;
    Fragment f;
    FirebaseAuth fAuth ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fAuth=FirebaseAuth.getInstance();
//
            FirebaseUser currentUser = fAuth.getCurrentUser();
            if (currentUser != null){
                Intent intent=new Intent(this, Home.class);
                startActivity(intent);
                fAuth.signOut();

            }
            else {
                loadFragment(new Login());

            }


    }

    private void loadFragment(Fragment fragment)
    {
        //create a fragment manager
        FragmentManager manager=getFragmentManager();
        //create the fragment transaction
        FragmentTransaction fd=manager.beginTransaction();
        fd.replace(R.id.frame,fragment);
        fd.commit();

    }
}