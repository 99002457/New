package com.example.socialinfluencer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;


import static com.example.socialinfluencer.Login.fAuth;
import static com.example.socialinfluencer.Login.mGoogleSignInClient;
public class Home extends AppCompatActivity {
    FirebaseAuth fAuth ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        fAuth= FirebaseAuth.getInstance();
        findViewById(R.id.SignOut).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fAuth!=null) {
                    fAuth.signOut();
                    mGoogleSignInClient.signOut();
                    finish();
                }
            }
        });
    }
}